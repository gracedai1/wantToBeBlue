//
//  ViewController.swift
//  wantToBeBlue
//
//  Created by student on 7/7/21.
//

import UIKit

class ViewController: UIViewController {
    var lightOn = false
    
    @IBOutlet var myLabel: UILabel!
    
    @IBOutlet var myButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myButton.setTitleColor(.black, for: .normal)
    }
//mvp
    @IBAction func buttonPressed(_ sender: Any) {
        lightOn.toggle()
        
        myLabel.textColor = .green
        myLabel.text = "It's not easy being green"
        view.backgroundColor = .blue

        
        /*if lightOn{view.backgroundColor = .blue}
        else {view.backgroundColor = .white}
        print("The button was pressed")*/
        
    }
    
//stretch 1
    @IBOutlet var button2: UIButton!
    
    @IBAction func whiteButton(_ sender: Any) {
        myLabel.text = "What color am I?"
        myLabel.textColor = .black
        view.backgroundColor = .white
    }
    
//stretch 2
    
    @IBOutlet var stretch2: UIButton!
    
    
    @IBAction func randomColor(_ sender: Any) {
        
            let redValue = CGFloat(drand48())
            let greenValue = CGFloat(drand48())
            let blueValue = CGFloat(drand48())
                         
            view.backgroundColor = UIColor (red: redValue, green: greenValue, blue: blueValue, alpha:1.0)
        }


    
    
    
}



